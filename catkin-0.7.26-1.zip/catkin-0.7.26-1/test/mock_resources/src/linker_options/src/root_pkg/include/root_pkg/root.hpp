namespace root_pkg
{
void func();
}
