#pragma once
namespace b {
  void foo();
}
