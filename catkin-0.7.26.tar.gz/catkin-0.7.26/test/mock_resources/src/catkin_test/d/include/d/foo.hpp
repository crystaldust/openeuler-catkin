#pragma once
namespace d {
  void foo();
}
